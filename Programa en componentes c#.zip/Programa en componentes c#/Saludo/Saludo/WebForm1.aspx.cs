﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Operaciones;

namespace Saludo
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        Operacion obj = new Operacion();
        string s = "";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string nombre = TxtNombre.Text;
            s = obj.saludo(nombre);
            
            TxtSaludo.Text = s;
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}