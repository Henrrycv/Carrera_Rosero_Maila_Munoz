//SaludoBeanRemote
package pkEJBBienvenida;

import javax.ejb.Remote;

/**
 *
 * @author Lizeth
 */
@Remote
public interface SaludoBeanRemote {

    void setNombre(String nm);

    String saludar();
    
}
