// BienvenidaCapaIntermedia.java
package bienvenidaclient;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import pkEJBBienvenida.SaludoBeanRemote;


public class BienvenidaCapaIntermedia {
    // Atributos:
    private InitialContext ibc;
    private SaludoBeanRemote cmp;
    
    // Metodos:
    public BienvenidaCapaIntermedia() {
        try {
            ibc = new InitialContext();
            cmp = (SaludoBeanRemote)ibc.lookup(
                    "java:global/EJBBienvenida1/SaludoBean!pkEJBBienvenida.SaludoBeanRemote");
                   // "pkEJBBienvenida.SaludoBeanRemote#pkEJBBienvenida.SaludoBeanRemote");
        } catch (NamingException ex) {
            Logger.getLogger(BienvenidaJF.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void setNombre(String val) {
        cmp.setNombre(val);
    }
    
    public String saludar() {
        return cmp.saludar();
    }
}
