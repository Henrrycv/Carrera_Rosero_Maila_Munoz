//SaludoBean
package pkEJBBienvenida;

import javax.ejb.Stateless;


@Stateless
public class SaludoBean implements SaludoBeanRemote {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    String Nom;

    @Override
    public void setNombre(String nm) {
           Nom=nm; 
    }

    @Override
    public String saludar() {
        return "hola como estas" + Nom;
    }
}
