//SaludoBeanRemote
package pkEJBBienvenida;

import javax.ejb.Remote;


@Remote
public interface SaludoBeanRemote {

    void setNombre(String nm);

    String saludar();
    
}
